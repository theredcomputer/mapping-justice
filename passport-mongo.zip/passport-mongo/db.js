module.exports = {
  'url' : 'mongodb://kevinhuntington:kevinhuntington@jello.modulusmongo.net:27017/ywuQus9i'

}


