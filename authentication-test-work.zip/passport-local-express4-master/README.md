## User Authentication With Passport and Express 4

View the blog post here: http://mherman.org/blog/2015/01/31/local-authentication-with-passport-and-express-4